#! /usr/bin/env python

import rospy

def main():

    rospy.init_node('yaml_editor',anonymous = True)
    joint_limits = rospy.get_param("/robot_description_planning/joint_limits/")
    print(joint_limits)
    rospy.set_param(joint_limits['revolute_joint_1']['max_velocity'],2.0)
    joint_limits = rospy.get_param("/robot_description_planning/joint_limits/")
    print(joint_limits)

if __name__ == "__main__":
    main()
